import React from 'react';
import IdentityCard from './IdentityCard';

function App() {
  // Example 1: Default values
  const student1 = {
    studentName: 'Sourabh Pal',
    fatherName: 'Shubham Singh Pal',
    motherName: 'Kanchan',
    studentClass: 'VI',
    dateOfBirth: '30/06/2014',
    address: 'Seoni. MP.',
    phoneNumber: '9123456789',
    studentPhoto: './pic.jpeg',
  };

  // Example 2: Different student
  const student2 = {
    studentName: 'Rahul Sharma',
    fatherName: 'Rajesh Sharma',
    motherName: 'Priya Sharma',
    studentClass: 'VIII',
    dateOfBirth: '15/03/2012',
    address: 'Mumbai, Maharashtra',
    phoneNumber: '9876543210',
    studentPhoto: './pic.jpeg', // Replace with actual photo path
  };

  // School information
  const schoolInfo = {
    schoolLogo: './logo.png',
    schoolName: 'Text for your School Name',
    registrationNumber: 'Reg. No. 1234567890',
    cardTitleImage: './identity-card.png',
    backgroundImage: './bg-front.png',
  };

  return (
    <div className="App">
      {/* Example Usage 1 */}
      <IdentityCard
        {...schoolInfo}
        {...student1}
      />

      {/* Example Usage 2 - Uncomment to see multiple cards */}
      {/* 
      <IdentityCard
        {...schoolInfo}
        {...student2}
      />
      */}
    </div>
  );
}

export default App;

